import 'package:flutter_test/flutter_test.dart';
import 'package:riskpulse/domain/gis/raster_data.dart';
import 'package:riskpulse/domain/gis/spatial_concepts.dart';
import 'package:riskpulse/domain/location/geo_location.dart';
import 'package:riskpulse/domain/gis/remote_sensing_band.dart';
import 'package:riskpulse/domain/gis/multispectral_product.dart';
import 'package:riskpulse/data/services/spectral_index_engine.dart';

void main() {
  group('Spectral Index Engine 4K.8.6 Scientific Validation Tests', () {
    final engine = SpectralIndexEngine();

    final testExtent = MapExtent(
      southWest: const GeoLocation(latitude: 31.0, longitude: 77.0),
      northEast: const GeoLocation(latitude: 31.05, longitude: 77.05),
    );

    // Band B4 (Red) - 10m res, scale 0.0001
    final redRaster = RasterData(
      width: 2,
      height: 2,
      cellWidth: 0.01,
      cellHeight: 0.01,
      origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
      crs: CoordinateReferenceSystem.wgs84,
      values: const [1000.0, 1000.0, 500.0, -9999.0], // Dense vegetation, Water, Land, NoData
      noDataValue: -9999.0,
      metadata: const {'datasetId': 'COPERNICUS/S2_SR_HARMONIZED'},
    );

    // Band B8 (NIR) - 10m res, scale 0.0001
    final nirRaster = RasterData(
      width: 2,
      height: 2,
      cellWidth: 0.01,
      cellHeight: 0.01,
      origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
      crs: CoordinateReferenceSystem.wgs84,
      values: const [4000.0, 500.0, 1500.0, 2000.0], // Dense vegetation, Water, Land, Valid
      noDataValue: -9999.0,
      metadata: const {'datasetId': 'COPERNICUS/S2_SR_HARMONIZED'},
    );

    // Band B3 (Green) - 10m res, scale 0.0001
    final greenRaster = RasterData(
      width: 2,
      height: 2,
      cellWidth: 0.01,
      cellHeight: 0.01,
      origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
      crs: CoordinateReferenceSystem.wgs84,
      values: const [800.0, 3000.0, 1200.0, 1000.0],
      noDataValue: -9999.0,
      metadata: const {'datasetId': 'COPERNICUS/S2_SR_HARMONIZED'},
    );

    test('1. NDVI numerical calculation executes correctly: (NIR - RED) / (NIR + RED)', () {
      final ndvi = engine.calculateNdvi(nir: nirRaster, red: redRaster);

      expect(ndvi.width, 2);
      expect(ndvi.height, 2);

      // Cell 0 (Dense vegetation): NIR=0.40, RED=0.10 => (0.40-0.10)/(0.40+0.10) = 0.30/0.50 = 0.60
      expect(ndvi.values[0], closeTo(0.60, 1e-4));

      // Cell 1 (Water): NIR=0.05, RED=0.10 => (0.05-0.10)/(0.05+0.10) = -0.05/0.15 = -0.3333
      expect(ndvi.values[1], closeTo(-0.3333, 1e-3));

      // Cell 2 (Land): NIR=0.15, RED=0.05 => (0.15-0.05)/(0.15+0.05) = 0.10/0.20 = 0.50
      expect(ndvi.values[2], closeTo(0.50, 1e-4));

      // Cell 3 (NoData in RED band): NoData propagation
      expect(ndvi.values[3], equals(-9999.0));
      expect(ndvi.isNoData(ndvi.values[3]), isTrue);
    });

    test('2. Case 2: NIR = RED yields exact 0.0 NDVI value', () {
      final equalRaster = RasterData(
        width: 1,
        height: 1,
        cellWidth: 0.01,
        cellHeight: 0.01,
        origin: const GeoLocation(latitude: 0, longitude: 0),
        crs: CoordinateReferenceSystem.wgs84,
        values: const [2000.0], // 0.20 reflectance
      );

      final ndvi = engine.calculateNdvi(nir: equalRaster, red: equalRaster);
      expect(ndvi.values[0], equals(0.0));
    });

    test('3. Reflectance scaling verification: Stored 1000 * 0.0001 scale = 0.10 physical reflectance', () {
      const stored = 1000.0;
      const scale = 0.0001;
      expect(stored * scale, closeTo(0.10, 1e-6));
    });

    test('4. NaN and Infinity inputs propagate as NoData without throwing', () {
      final nanRaster = RasterData(
        width: 2,
        height: 2,
        cellWidth: 0.01,
        cellHeight: 0.01,
        origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
        crs: CoordinateReferenceSystem.wgs84,
        values: const [double.nan, 1000.0, 1000.0, 1000.0],
      );

      final infRaster = RasterData(
        width: 2,
        height: 2,
        cellWidth: 0.01,
        cellHeight: 0.01,
        origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
        crs: CoordinateReferenceSystem.wgs84,
        values: const [1000.0, double.infinity, 1000.0, 1000.0],
      );

      final ndvi1 = engine.calculateNdvi(nir: nanRaster, red: redRaster);
      final ndvi2 = engine.calculateNdvi(nir: nirRaster, red: infRaster);

      expect(ndvi1.values[0], equals(-9999.0));
      expect(ndvi2.values[1], equals(-9999.0));
    });

    test('5. Zero denominator (0 + 0) propagation sets NoData cleanly without NaN', () {
      final zeroNIR = RasterData(
        width: 1,
        height: 1,
        cellWidth: 0.01,
        cellHeight: 0.01,
        origin: const GeoLocation(latitude: 0, longitude: 0),
        crs: CoordinateReferenceSystem.wgs84,
        values: const [0.0],
      );

      final zeroRED = RasterData(
        width: 1,
        height: 1,
        cellWidth: 0.01,
        cellHeight: 0.01,
        origin: const GeoLocation(latitude: 0, longitude: 0),
        crs: CoordinateReferenceSystem.wgs84,
        values: const [0.0],
      );

      final ndvi = engine.calculateNdvi(nir: zeroNIR, red: zeroRED);

      expect(ndvi.values[0], equals(-9999.0));
      expect(ndvi.values[0].isNaN, isFalse);
    });

    test('6. Dimension mismatch throws ArgumentError', () {
      final mismatchNIR = RasterData(
        width: 3, // 3x2 vs 2x2
        height: 2,
        cellWidth: 0.01,
        cellHeight: 0.01,
        origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
        crs: CoordinateReferenceSystem.wgs84,
        values: const [1, 2, 3, 4, 5, 6],
      );

      expect(() => engine.calculateNdvi(nir: mismatchNIR, red: redRaster), throwsArgumentError);
    });

    test('7. CRS mismatch throws ArgumentError', () {
      final mismatchCrsNIR = RasterData(
        width: 2,
        height: 2,
        cellWidth: 0.01,
        cellHeight: 0.01,
        origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
        crs: const CoordinateReferenceSystem(code: 'EPSG:32644', name: 'UTM Zone 44N'),
        values: const [4000, 500, 1500, 2000],
      );

      expect(() => engine.calculateNdvi(nir: mismatchCrsNIR, red: redRaster), throwsArgumentError);
    });

    test('8. NDVI and NDWI from MultispectralProduct operates cleanly', () {
      final product = MultispectralProduct(
        productId: 's2-test-01',
        providerId: 'gee',
        datasetId: 'COPERNICUS/S2_SR_HARMONIZED',
        acquisitionDate: DateTime.now(),
        crs: CoordinateReferenceSystem.wgs84,
        extent: testExtent,
        bands: const [
          RemoteSensingBand.sentinel2B3,
          RemoteSensingBand.sentinel2B4,
          RemoteSensingBand.sentinel2B8,
        ],
        bandRasters: {
          'B3': greenRaster,
          'B4': redRaster,
          'B8': nirRaster,
        },
      );

      final ndvi = engine.calculateNdviFromProduct(product);
      final ndwi = engine.calculateNdwiFromProduct(product);

      expect(ndvi.metadata['analysis_type'], 'NDVI');
      expect(ndvi.metadata['units'], 'index (-1 to +1)');
      expect(ndwi.metadata['analysis_type'], 'NDWI');
      expect(ndwi.metadata['units'], 'index (-1 to +1)');
    });
  });
}
