import 'package:flutter_test/flutter_test.dart';
import 'package:riskpulse/domain/gis/raster_data.dart';
import 'package:riskpulse/domain/gis/spatial_concepts.dart';
import 'package:riskpulse/domain/location/geo_location.dart';
import 'package:riskpulse/domain/gis/quality_mask.dart';
import 'package:riskpulse/domain/gis/remote_sensing_band.dart';
import 'package:riskpulse/domain/gis/multispectral_product.dart';
import 'package:riskpulse/data/services/cloud_masking_engine.dart';
import 'package:riskpulse/data/services/spectral_index_engine.dart';

void main() {
  group('Sentinel-2 Cloud & Quality Masking Foundation 4K.9.1 Tests', () {
    final maskEngine = CloudMaskingEngine();
    final indexEngine = SpectralIndexEngine();

    final testExtent = MapExtent(
      southWest: const GeoLocation(latitude: 31.0, longitude: 77.0),
      northEast: const GeoLocation(latitude: 31.05, longitude: 77.05),
    );

    // Band B4 (Red) - 2x2 cells
    final redRaster = RasterData(
      width: 2,
      height: 2,
      cellWidth: 0.01,
      cellHeight: 0.01,
      origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
      crs: CoordinateReferenceSystem.wgs84,
      values: const [1000.0, 1000.0, 500.0, -9999.0],
      noDataValue: -9999.0,
    );

    // Band B8 (NIR) - 2x2 cells
    final nirRaster = RasterData(
      width: 2,
      height: 2,
      cellWidth: 0.01,
      cellHeight: 0.01,
      origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
      crs: CoordinateReferenceSystem.wgs84,
      values: const [4000.0, 4000.0, 1500.0, 2000.0],
      noDataValue: -9999.0,
    );

    // QA60 Band Raster (Bit 10 = Opaque Cloud, Bit 11 = Cirrus)
    final qa60Raster = RasterData(
      width: 2,
      height: 2,
      cellWidth: 0.01,
      cellHeight: 0.01,
      origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
      crs: CoordinateReferenceSystem.wgs84,
      values: const [0.0, 1024.0, 2048.0, -9999.0], // Clear, Opaque Cloud, Cirrus Cloud, NoData
      noDataValue: -9999.0,
    );

    // SCL Band Raster (Classes: 4=Veg (Valid), 8=Cloud Med (Invalid), 3=Cloud Shadow (Invalid), 0=NoData)
    final sclRaster = RasterData(
      width: 2,
      height: 2,
      cellWidth: 0.01,
      cellHeight: 0.01,
      origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
      crs: CoordinateReferenceSystem.wgs84,
      values: const [4.0, 8.0, 3.0, 0.0], // Valid, Cloud, Shadow, NoData
      noDataValue: -9999.0,
    );

    test('1. QA60 mask building correctly identifies opaque (bit 10) and cirrus (bit 11) clouds', () {
      final mask = maskEngine.buildMaskFromQA60(qa60Raster);

      expect(mask.width, 2);
      expect(mask.height, 2);
      expect(mask.qualitySource, contains('QA60'));
      expect(mask.isValid(0), isTrue); // Cell 0: Clear
      expect(mask.maskStates[1], QualityPixelState.cloud); // Cell 1: Opaque Cloud
      expect(mask.maskStates[2], QualityPixelState.cirrus); // Cell 2: Cirrus Cloud
      expect(mask.maskStates[3], QualityPixelState.noData); // Cell 3: NoData
      expect(mask.validPixels, 1);
      expect(mask.maskedPixels, 3);
      expect(mask.validPercentage, equals(25.0));
    });

    test('2. SCL mask building correctly identifies valid vegetation vs invalid cloud/shadow classes', () {
      final mask = maskEngine.buildMaskFromSCL(sclRaster);

      expect(mask.isValid(0), isTrue); // Cell 0: SCL=4 (Vegetation)
      expect(mask.maskStates[1], QualityPixelState.cloud); // Cell 1: SCL=8 (Cloud)
      expect(mask.maskStates[2], QualityPixelState.cloudShadow); // Cell 2: SCL=3 (Shadow)
      expect(mask.validPixels, 1);
      expect(mask.maskedPixels, 3);
      expect(mask.validPercentage, equals(25.0));
    });

    test('3. applyMask preserves clear pixels and converts cloudy pixels to NoData (-9999.0)', () {
      final mask = maskEngine.buildMaskFromQA60(qa60Raster);
      final maskedRed = maskEngine.applyMask(sourceRaster: redRaster, mask: mask);

      expect(maskedRed.values[0], equals(1000.0)); // Cell 0: Valid, preserved
      expect(maskedRed.values[1], equals(-9999.0)); // Cell 1: Masked Opaque Cloud -> NoData
      expect(maskedRed.values[2], equals(-9999.0)); // Cell 2: Masked Cirrus Cloud -> NoData
      expect(maskedRed.values[3], equals(-9999.0)); // Cell 3: Original NoData preserved
    });

    test('4. Provenance and quality statistics metadata are attached to masked RasterData', () {
      final mask = maskEngine.buildMaskFromQA60(qa60Raster);
      final maskedRed = maskEngine.applyMask(sourceRaster: redRaster, mask: mask);

      expect(maskedRed.metadata['quality_masked'], isTrue);
      expect(maskedRed.metadata['quality_source'], contains('QA60'));
      expect(maskedRed.metadata['valid_pixels'], 1);
      expect(maskedRed.metadata['masked_pixels'], 3);
      expect(maskedRed.metadata['valid_percentage'], equals(25.0));
    });

    test('5. Source RasterData values array remains 100% immutable after masking', () {
      final val0Before = redRaster.values[0];
      final val1Before = redRaster.values[1];

      final mask = maskEngine.buildMaskFromQA60(qa60Raster);
      maskEngine.applyMask(sourceRaster: redRaster, mask: mask);

      expect(redRaster.values[0], equals(val0Before));
      expect(redRaster.values[1], equals(val1Before));
    });

    test('6. Dimension mismatch between source raster and quality mask throws ArgumentError', () {
      final mismatchRaster = RasterData(
        width: 3, // 3x2 vs 2x2
        height: 2,
        cellWidth: 0.01,
        cellHeight: 0.01,
        origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
        crs: CoordinateReferenceSystem.wgs84,
        values: const [1, 2, 3, 4, 5, 6],
      );

      final mask = maskEngine.buildMaskFromQA60(qa60Raster);

      expect(() => maskEngine.applyMask(sourceRaster: mismatchRaster, mask: mask), throwsArgumentError);
    });

    test('7. CRS mismatch between source raster and quality mask throws ArgumentError', () {
      final mismatchCrsRaster = RasterData(
        width: 2,
        height: 2,
        cellWidth: 0.01,
        cellHeight: 0.01,
        origin: const GeoLocation(latitude: 31.05, longitude: 77.0),
        crs: const CoordinateReferenceSystem(code: 'EPSG:32644', name: 'UTM Zone 44N'),
        values: const [1000, 1000, 500, -9999],
      );

      final mask = maskEngine.buildMaskFromQA60(qa60Raster);

      expect(() => maskEngine.applyMask(sourceRaster: mismatchCrsRaster, mask: mask), throwsArgumentError);
    });

    test('8. Quality-masked bands integrate seamlessly with SpectralIndexEngine for NDVI calculation', () {
      final mask = maskEngine.buildMaskFromQA60(qa60Raster);

      final maskedRed = maskEngine.applyMask(sourceRaster: redRaster, mask: mask);
      final maskedNir = maskEngine.applyMask(sourceRaster: nirRaster, mask: mask);

      final maskedNdvi = indexEngine.calculateNdvi(nir: maskedNir, red: maskedRed);

      // Cell 0 (Clear): Valid NDVI calculated => (0.40-0.10)/(0.40+0.10) = 0.60
      expect(maskedNdvi.values[0], closeTo(0.60, 1e-4));

      // Cells 1, 2, 3 (Cloudy / NoData): Masked out, index engine propagates NoData
      expect(maskedNdvi.values[1], equals(-9999.0));
      expect(maskedNdvi.values[2], equals(-9999.0));
      expect(maskedNdvi.values[3], equals(-9999.0));
    });

    test('9. applyMaskToProduct applies quality mask across all product band rasters', () {
      final product = MultispectralProduct(
        productId: 's2-mask-01',
        providerId: 'gee',
        datasetId: 'COPERNICUS/S2_SR_HARMONIZED',
        acquisitionDate: DateTime.now(),
        crs: CoordinateReferenceSystem.wgs84,
        extent: testExtent,
        bands: const [RemoteSensingBand.sentinel2B4, RemoteSensingBand.sentinel2B8],
        bandRasters: {'B4': redRaster, 'B8': nirRaster},
      );

      final mask = maskEngine.buildMaskFromQA60(qa60Raster);
      final maskedProduct = maskEngine.applyMaskToProduct(product: product, mask: mask);

      expect(maskedProduct.productId, 's2-mask-01-masked');
      expect(maskedProduct.metadata['quality_masked'], isTrue);
      expect(maskedProduct.getBandRaster('B4')?.values[1], equals(-9999.0));
      expect(maskedProduct.getBandRaster('B8')?.values[1], equals(-9999.0));
    });
  });
}
