import 'dart:math' as math;
import 'package:riskpulse/domain/gis/spatial_concepts.dart';
import 'package:riskpulse/domain/gis/raster_data.dart';
import 'package:riskpulse/domain/gis/remote_sensing_band.dart';
import 'package:riskpulse/domain/gis/multispectral_product.dart';
import 'package:riskpulse/domain/gis/remote_sensing_query.dart';
import 'package:riskpulse/domain/gis/remote_sensing_provider.dart';
import 'package:riskpulse/domain/gis/research_data_provider.dart';
import 'package:riskpulse/data/services/gee/gee_client.dart';
import 'package:riskpulse/data/services/geotiff_reader.dart';

/// Provider implementation acquiring Sentinel-2 L2A multispectral products from Google Earth Engine (`COPERNICUS/S2_SR_HARMONIZED`).
class GeeRemoteSensingProvider implements RemoteSensingProvider {
  final GeeClient _client;
  final GeoTiffReader _reader;

  GeeRemoteSensingProvider({
    GeeClient? client,
    GeoTiffReader? reader,
  })  : _client = client ?? GeeClient(),
        _reader = reader ?? GeoTiffReader();

  @override
  String get providerId => 'gee';

  @override
  String get displayName => 'Google Earth Engine';

  static const int maxMaterializationDimension = 2500;
  static const int maxMaterializationCells = 6250000;

  @override
  Future<DataProviderResult<MultispectralProduct>> fetchProduct(
    RemoteSensingQuery query, {
    String? accessToken,
  }) async {
    final String datasetId = query.datasetId ?? 'COPERNICUS/S2_SR_HARMONIZED';

    // 1. Validate Extent
    if (query.extent.southWest.latitude >= query.extent.northEast.latitude ||
        query.extent.southWest.longitude >= query.extent.northEast.longitude) {
      return DataProviderResult.failure(
        const DataProviderError(
          type: DataProviderErrorType.invalidRequest,
          message: 'Invalid MapExtent: SouthWest must be strictly less than NorthEast.',
          providerId: 'gee',
        ),
      );
    }

    // 2. Validate Temporal Range
    if (query.startDate.isAfter(query.endDate)) {
      return DataProviderResult.failure(
        const DataProviderError(
          type: DataProviderErrorType.invalidRequest,
          message: 'Invalid temporal range: startDate must be before or equal to endDate.',
          providerId: 'gee',
        ),
      );
    }

    // 3. Memory Boundary Safeguard
    final double latMid = (query.extent.southWest.latitude + query.extent.northEast.latitude) / 2.0;
    final double dyMeters = (query.extent.northEast.latitude - query.extent.southWest.latitude) * 111320.0;
    final double dxMeters = (query.extent.northEast.longitude - query.extent.southWest.longitude) * 111320.0 * math.cos(latMid * math.pi / 180.0);

    const double nominalResMeters = 10.0; // Sentinel-2 nominal resolution
    final int estimatedWidth = (dxMeters / nominalResMeters).ceil();
    final int estimatedHeight = (dyMeters / nominalResMeters).ceil();
    final int totalCells = estimatedWidth * estimatedHeight;

    if (estimatedWidth > maxMaterializationDimension ||
        estimatedHeight > maxMaterializationDimension ||
        totalCells > maxMaterializationCells) {
      return DataProviderResult.failure(
        DataProviderError(
          type: DataProviderErrorType.invalidRequest,
          message: 'Requested AOI ($estimatedWidth x $estimatedHeight cells) exceeds local materialization boundary (max $maxMaterializationDimension x $maxMaterializationDimension cells).',
          providerId: 'gee',
        ),
      );
    }

    // 4. Authentication Check
    if (accessToken == null || accessToken.trim().isEmpty) {
      return DataProviderResult.failure(
        const DataProviderError(
          type: DataProviderErrorType.unauthorized,
          message: 'GEE authentication required. Please provide a valid GCP / Earth Engine Bearer Access Token.',
          providerId: 'gee',
        ),
      );
    }

    final double cellHeightDeg = (query.extent.northEast.latitude - query.extent.southWest.latitude) / estimatedHeight;
    final double cellWidthDeg = (query.extent.northEast.longitude - query.extent.southWest.longitude) / estimatedWidth;

    try {
      final Map<String, RasterData> bandRasters = {};
      final List<RemoteSensingBand> bandDefs = [];

      for (final bandId in query.requestedBands) {
        final def = RemoteSensingBand.sentinel2Bands[bandId];
        if (def == null) continue;

        final bytes = await _client.computeDemPixels(
          extent: query.extent,
          cellWidthDeg: cellWidthDeg,
          cellHeightDeg: cellHeightDeg,
          accessToken: accessToken,
          datasetId: datasetId,
        );

        final raster = _reader.decode(bytes);
        bandRasters[bandId] = raster;
        bandDefs.add(def);
      }

      if (bandRasters.isEmpty) {
        return DataProviderResult.failure(
          const DataProviderError(
            type: DataProviderErrorType.invalidRasterData,
            message: 'No valid bands retrieved for requested Sentinel-2 query.',
            providerId: 'gee',
          ),
        );
      }

      final product = MultispectralProduct(
        productId: 's2-${query.startDate.millisecondsSinceEpoch}',
        providerId: providerId,
        datasetId: datasetId,
        acquisitionDate: query.startDate,
        crs: CoordinateReferenceSystem.wgs84,
        extent: query.extent,
        cloudCoverPercentage: query.maxCloudCoverPercentage,
        bands: bandDefs,
        bandRasters: bandRasters,
        metadata: {
          'provider': displayName,
          'datasetId': datasetId,
          'maxCloudCover': query.maxCloudCoverPercentage,
        },
      );

      return DataProviderResult.success(product);

    } catch (e) {
      if (e is DataProviderError) return DataProviderResult.failure(e);
      return DataProviderResult.failure(
        DataProviderError(
          type: DataProviderErrorType.networkFailure,
          message: 'Failed to acquire Sentinel-2 product: $e',
          providerId: 'gee',
        ),
      );
    }
  }
}
